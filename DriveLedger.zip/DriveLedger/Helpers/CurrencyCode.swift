//
//  CurrencyCode.swift
//  DriveLedger
//
//  Provides a module-wide currency code constant to avoid duplication.
//

import Foundation

let currencyCode = DLFormatters.currencyCode
