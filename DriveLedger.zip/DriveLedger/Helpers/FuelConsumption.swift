import Foundation

enum FuelConsumption {
    /// Расход считаем только по "полным бакам".
    /// Литры берём как сумму всех fuel-записей между предыдущим full и текущим full (включая доливы),
    /// чтобы доливы не ломали математику.
    static func compute(
        currentEntryID: UUID?,
        currentDate: Date,
        currentOdo: Int?,
        currentLitersDraft: Double?,
        currentFillKind: FuelFillKind,
        existingEntries: [LogEntry]
    ) -> Double? {
        guard currentFillKind == .full else { return nil }
        guard let currentOdo, currentOdo > 0 else { return nil }
        let prevFull = existingEntries
            .filter { $0.kind == .fuel }
            .filter { $0.id != currentEntryID }
            .filter { $0.date < currentDate }
            .filter { $0.fuelFillKind == .full }
            .filter { ($0.odometerKm ?? 0) > 0 }
            .sorted { $0.date > $1.date }
            .first

        guard let prevFull,
              let prevOdo = prevFull.odometerKm,
              currentOdo > prevOdo
        else { return nil }

        let distance = Double(currentOdo - prevOdo)
        guard distance > 0 else { return nil }

        let litersBetween = existingEntries
            .filter { $0.kind == .fuel }
            .filter { $0.id != currentEntryID }
            .filter { $0.date > prevFull.date && $0.date <= currentDate }
            .compactMap { $0.fuelLiters }
            .reduce(0, +)

        let totalLiters = litersBetween + (currentLitersDraft ?? 0)
        guard totalLiters > 0 else { return nil }

        return (totalLiters / distance) * 100.0
    }

    /// Пересчитывает расход по всем топливным записям.
    /// Логика такая же, как в `compute`: расход считаем только для заправок типа `.full`.
    /// Для каждой `.full` записи берём дистанцию от предыдущей `.full` (с валидным одометром)
    /// и литры как сумму всех fuel-записей между ними + литры текущей записи.
    static func recalculateAll(existingEntries: [LogEntry]) {
        let fuelEntries = existingEntries
            .filter { $0.kind == .fuel }
            .sorted { $0.date < $1.date }

        // Сбрасываем расход у всех не-full и/или невалидных записей
        for e in fuelEntries {
            if e.fuelFillKind != .full {
                e.fuelConsumptionLPer100km = nil
            }
        }

        // Для каждой full-записи считаем расход от предыдущей full
        for current in fuelEntries where current.fuelFillKind == .full {
            guard let currentOdo = current.odometerKm, currentOdo > 0 else {
                current.fuelConsumptionLPer100km = nil
                continue
            }
            guard let currentLiters = current.fuelLiters, currentLiters > 0 else {
                current.fuelConsumptionLPer100km = nil
                continue
            }

            // предыдущая full запись (по дате), с валидным одометром
            let prevFull = fuelEntries
                .filter { $0.date < current.date }
                .filter { $0.fuelFillKind == .full }
                .filter { ($0.odometerKm ?? 0) > 0 }
                .last

            guard let prevFull, let prevOdo = prevFull.odometerKm, currentOdo > prevOdo else {
                current.fuelConsumptionLPer100km = nil
                continue
            }

            let distance = Double(currentOdo - prevOdo)
            guard distance > 0 else {
                current.fuelConsumptionLPer100km = nil
                continue
            }

            // литры между prevFull и current (исключая current) + current
            let litersBetween = fuelEntries
                .filter { $0.date > prevFull.date && $0.date < current.date }
                .compactMap { $0.fuelLiters }
                .reduce(0, +)

            let totalLiters = litersBetween + currentLiters
            guard totalLiters > 0 else {
                current.fuelConsumptionLPer100km = nil
                continue
            }

            current.fuelConsumptionLPer100km = (totalLiters / distance) * 100.0
        }
    }
}
